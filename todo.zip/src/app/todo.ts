export class Todo{
    sno: number = 0
    title: string = ''
    desc: string = ''
    active: boolean  = true
}